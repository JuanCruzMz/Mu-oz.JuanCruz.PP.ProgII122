
package festivaldeciencia;


public class Charla extends ActividadEducativa implements Presentable, Reservable
{
    private int minutosDePreguntas;
    private int cuposDisponibles;
    
    public Charla(String codigo, String titulo, FranjaHoraria FranjaHoraria, int duracionBaseEnMinutos, int minutosDePreguntas, int cuposDisponibles)
    {
        if(minutosDePreguntas <= 0)
        {
            throw new IllegalArgumentException("La duración de los minutos de preguntas debe ser mayor a cero.");
        }
        
        int duracionTotal = duracionBaseEnMinutos + minutosDePreguntas;
        
        
        if(cuposDisponibles <= 0)
        {
            throw new IllegalArgumentException("Los cupos disponibles no pueden ser menos que cero.");
        }
        else
        {
            this.cuposDisponibles = cuposDisponibles;
        }
        
        super(codigo, titulo, FranjaHoraria, duracionTotal);
    }

    
    public int getMinutosDePreguntas()
    {
        return minutosDePreguntas;
    }
    public int getCuposDisponibles()
    {
        return cuposDisponibles;
    }

    
    @Override
    public void reservarLugar()
    {
        if(cuposDisponibles <= 0)
        {
            throw new IllegalStateException("No quedan cupos disponibles.");
        }
        else
        {
            cuposDisponibles -= cuposDisponibles;
            System.out.println("Reserva confirmada para " + this.getTitulo() + ". Cupos restantes: " + cuposDisponibles);
        }
    }
    
    @Override
    public void presentable()
    {
        System.out.println("Se está realizando una presentación interactiva.");
    }
}
