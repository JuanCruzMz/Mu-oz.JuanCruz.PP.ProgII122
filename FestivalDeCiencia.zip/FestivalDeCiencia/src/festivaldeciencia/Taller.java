
package festivaldeciencia;


public class Taller extends ActividadEducativa implements Reservable
{
    private int minutosDePractica;
    private int cuposDisponibles;
    
    public Taller(String codigo, String titulo, FranjaHoraria FranjaHoraria, int duracionBaseEnMinutos, int minutosDePractica, int cuposDisponibles)
    {
        if(minutosDePractica <= 0)
        {
            throw new IllegalArgumentException("La duración de los minutos de práctica debe ser mayor a cero.");
        }
        
        int duracionTotal = duracionBaseEnMinutos + minutosDePractica;
        
        
        if(cuposDisponibles <= 0)
        {
            throw new IllegalArgumentException("Los cupos disponibles no pueden ser menos que cero.");
        }
        else
        {
            this.cuposDisponibles = cuposDisponibles;
        }
        
        super(codigo, titulo, FranjaHoraria, duracionTotal);
    }

    
    public int getMinutosDePractica()
    {
        return minutosDePractica;
    }
    public int getCuposDisponibles()
    {
        return cuposDisponibles;
    }


    @Override
    public void reservarLugar()
    {
        if(cuposDisponibles <= 0)
        {
            throw new IllegalStateException("No quedan cupos disponibles.");
        }
        else
        {
            cuposDisponibles -= cuposDisponibles;
            System.out.println("Reserva confirmada para " + this.getTitulo() + ". Cupos restantes: " + cuposDisponibles);
        }
    }
}
