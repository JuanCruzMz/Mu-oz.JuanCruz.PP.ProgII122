package festivaldeciencia;

/**
 *
 * @author juanc
 */
public interface Reservable
{
    void reservarLugar();
}
