
package festivaldeciencia;

import java.util.Objects;


public abstract class ActividadEducativa
{
    private String codigo;
    private String titulo;
    private FranjaHoraria FranjaHoraria;
    private int duracionBaseEnMinutos;

    
    public ActividadEducativa(String codigo, String titulo, FranjaHoraria FranjaHoraria, int duracionBaseEnMinutos)
    {
        if (codigo == null || codigo.isBlank())
        {
            throw new IllegalArgumentException("El código no puede ser nulo ni estar en blanco.");
        }
        else
        {
            this.codigo = codigo;
        }
        
        if (titulo == null || titulo.isBlank())
        {
            throw new IllegalArgumentException("El título no puede ser nulo ni estar en blanco.");
        }
        else
        {
            this.titulo = titulo;
        }
        
        if (FranjaHoraria == null)
        {
            throw new IllegalArgumentException("La franja horaria es obligatoria.");
        }
        else
        {
            this.FranjaHoraria = FranjaHoraria;
        }
        
        if (duracionBaseEnMinutos <= 0)
        {
            throw new IllegalArgumentException("La duración base debe ser mayor a cero.");
        }
        else
        {
            this.duracionBaseEnMinutos = duracionBaseEnMinutos;
        }
    }

    
    public String getCodigo()
    {
        return codigo;
    }
    public String getTitulo()
    {
        return titulo;
    }
    public FranjaHoraria getFranjaHoraria()
    {
        return FranjaHoraria;
    }
    public int getDuracionBaseEnMinutos()
    {
        return duracionBaseEnMinutos;
    }
    
    
    @Override
    public int hashCode()
    {
        int hash = 3;
        
        hash = 47 * hash + Objects.hashCode(this.codigo);
        hash = 47 * hash + Objects.hashCode(this.titulo);
        
        return hash;
    }

    
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (!(obj instanceof ActividadEducativa))
        {
            return false;
        }
        
        final ActividadEducativa other = (ActividadEducativa) obj;
        
        if (!Objects.equals(this.codigo, other.codigo))
        {
            return false;
        }
        return Objects.equals(this.titulo, other.titulo);
    }
}