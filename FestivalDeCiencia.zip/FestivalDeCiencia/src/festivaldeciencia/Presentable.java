package festivaldeciencia;

/**
 *
 * @author juanc
 */
public interface Presentable
{
    void presentable();
}
