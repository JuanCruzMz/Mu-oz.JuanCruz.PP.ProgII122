package festivaldeciencia;

import java.util.List;

public class FestivalDeCiencia
{
    public static void main(String[] args)
    {
        Festival festival = new Festival("Ciencia Abierta");

        festival.agregarActividad(new Charla("C01", "IA Creativa",
                FranjaHoraria.MATUTINA, 40, 10, 2));
        festival.agregarActividad(new Taller("T02", "Robotica",
                FranjaHoraria.VESPERTINA, 60, 30, 1));
        festival.agregarActividad(new MuestraInteractiva("M03", "Ciencia Viva",
                FranjaHoraria.MATUTINA, 25, 4));
        festival.agregarActividad(new Charla("C04", "Astronomia",
                FranjaHoraria.NOCTURNA, 35, 15, 1));
        
        try
        {
            festival.agregarActividad(new Taller("C01", "IA Creativa",
                FranjaHoraria.NOCTURNA, 20, 5, 3));
        }
        catch (ActividadDuplicadaException e)
        {
            System.out.println("Duplicado: " + e.getMessage());
        }
        
        
        System.out.println("ACTIVIDADES");
        mostrarActividades(festival.obtenerActividades());
        System.out.println("DURACIONES");
        mostrarDuraciones(festival.obtenerActividades());
        System.out.println("PRESENTACIONES");
        realizarPresentaciones(festival.obtenerActividades());
        System.out.println("RESERVAS");
        reservarActividades(festival.obtenerActividades());
        System.out.println("MATUTINA");
        mostrarActividades(festival.filtrarPorFranja(FranjaHoraria.MATUTINA));
        System.out.println("HASTA 50 MINUTOS");
        mostrarActividades(festival.obtenerActividadesDeDuracionMaxima(50));
    }

    private static void mostrarActividades(List<ActividadEducativa> actividades)
    {
        for (ActividadEducativa a : actividades)
        {
            System.out.println("- " + a.getTitulo() + " (Código: " + a.getCodigo() + ", Rango: " + a.getFranjaHoraria() + ", duración base: " + a.getDuracionBaseEnMinutos() + ")");
        }
    }

    private static void mostrarDuraciones(List<ActividadEducativa> actividades)
    {
        for (ActividadEducativa a : actividades)
        {
            System.out.println(a.getTitulo() + " " + a.getDuracionBaseEnMinutos() + " minutos");
        }
    }

    private static void realizarPresentaciones(List<ActividadEducativa> actividades)
    {
        for (ActividadEducativa a : actividades)
        {
            if (a instanceof Presentable p)
            {
                p.presentable();
            }
            else
            {
                System.out.println("Esta actividad no realiza presentaciones");
            }
        }
    }

    private static void reservarActividades(List<ActividadEducativa> actividades)
    {
        for (ActividadEducativa a : actividades)
        {
            if (a instanceof Reservable r)
            {
                r.reservarLugar();
            }
            else
            {
                System.out.println("Esta actividad no es reservable");
            }
        }
    }
}