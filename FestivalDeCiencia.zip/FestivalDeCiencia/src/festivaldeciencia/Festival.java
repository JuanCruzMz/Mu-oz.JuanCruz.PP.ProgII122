
package festivaldeciencia;

import java.util.List;
import java.util.ArrayList;


public class Festival
{
    private String nombre;
    private List<ActividadEducativa> listaDeActividades;

    
    public Festival(String nombre)
    {
        this.nombre = nombre;
        this.listaDeActividades = new ArrayList<>();
    }
    
    /**
     * Agrega una actividad al festival.
     * Si ya existe una igual (mismo código y título), lanza excepción.
     */
    public void agregarActividad(ActividadEducativa actividad)
    {
        if (this.listaDeActividades.contains(actividad))
        {
            throw new ActividadDuplicadaException("Ya existe la actividad " + actividad.getCodigo() + " - " + actividad.getTitulo());
        }
        
        this.listaDeActividades.add(actividad);
    }

    /**
     * Devuelve una lista con las actividades registradas.
     */
    public List obtenerActividades()
    {
        return listaDeActividades;
    }
    
    /**
     * Devuelve las actividades en la franja horaria especificada.
     */
    public List<ActividadEducativa> filtrarPorFranja(FranjaHoraria franjaHoraria)
    {
        List<ActividadEducativa> filtradas = new ArrayList<>();
        
        for (ActividadEducativa a : this.listaDeActividades)
        {
            if (a.getFranjaHoraria() == franjaHoraria)
            {
                filtradas.add(a);
            }
        }
        
        return filtradas;
    }
    
    /**
     * Devuelve las actividades con una duracion mayor a la recibida.
     */
    public List<ActividadEducativa> obtenerActividadesDeDuracionMaxima(int duracionMinima)
    {
        if(duracionMinima <= 0)
        {
            throw new IllegalArgumentException("La duración mínima debe ser mayor a cero.");
        }
        else
        {
            List<ActividadEducativa> filtradas = new ArrayList<>();
        
            for (ActividadEducativa a : this.listaDeActividades)
            {
                if (a.getDuracionBaseEnMinutos() >= duracionMinima)
                {
                    filtradas.add(a);
                }
            }
            
            return filtradas;
        }
    }
}