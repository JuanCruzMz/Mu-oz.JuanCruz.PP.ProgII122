
package festivaldeciencia;


public class ActividadDuplicadaException extends RuntimeException
{
    public ActividadDuplicadaException(String mensaje)
    {
        super(mensaje);
    }
}
