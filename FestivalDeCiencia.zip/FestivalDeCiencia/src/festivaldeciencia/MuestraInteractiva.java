
package festivaldeciencia;


public class MuestraInteractiva extends ActividadEducativa implements Presentable
{
    private int cantidadDeEstaciones;
    
    public MuestraInteractiva(String codigo, String titulo, FranjaHoraria FranjaHoraria, int duracionBaseEnMinutos, int cantidadDeEstaciones)
    {
        if(cantidadDeEstaciones <= 0)
        {
            throw new IllegalArgumentException("La cantidad de estaciones debe ser mayor a cero.");
        }
        
        int duracionTotal = duracionBaseEnMinutos + 5 * cantidadDeEstaciones;
        
        super(codigo, titulo, FranjaHoraria, duracionTotal);
    }

    
    public int getCantidadDeEstaciones()
    {
        return cantidadDeEstaciones;
    }
    
    
    @Override
    public void presentable()
    {
        System.out.println("Se está realizando una presentación interactiva.");
    }
}
